# Gerber files

The `files/` directory contains the complete fabrication set:

- top and bottom copper
- top and bottom solder mask
- neutral top and bottom silkscreen
- board profile
- plated and non-plated drill files
- Gerber job file

To order boards, ZIP the **contents** of `files/` so the Gerber files are at the root of the archive.

The public bottom silkscreen is device-neutral. Copper, masks, drills, and outline are unchanged from the KiCad 10.0.5 DRC-clean electrical baseline.

Recommended first-prototype settings: 2 layers, FR-4, 1.6 mm, 1 oz copper, lead-free HASL or ENIG.
